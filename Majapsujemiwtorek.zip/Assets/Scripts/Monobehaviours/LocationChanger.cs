using UnityEngine;


public class LocationChanger : MonoBehaviour
{
    [Tooltip("Wpisz tutaj ID pokoju, do kt�rego prowadz� te drzwi, np. Korytarz")]
    public string targetLocationId;
}
